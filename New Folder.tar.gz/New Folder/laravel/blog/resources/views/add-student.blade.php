<div>
    <h1> add new student</h1>
    <form action=" " method="POST">
    @csrf
    <input type="text" name="name" placeholder="Name">
    <input type="email" name="email" placeholder="Email">
    <input type="text" name="phone" placeholder="Phone">
    <button type="submit">Add Student</button>
</form>

</div>
