<div>
    <h1>Update Student Details</h1>

    <form action="/edit-student/<?php echo e($data->id); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <input type="text" name="name" value="<?php echo e($data->name); ?>" placeholder="Enter Name">
        <br><br>

        <input type="email" name="email" value="<?php echo e($data->email); ?>" placeholder="Enter Email">
        <br><br>

        <input type="text" name="phone" value="<?php echo e($data->phone); ?>" placeholder="Enter Phone">
        <br><br>

        <button type="submit">Update Details</button>
        <a href="/list">Cancel</a>
    </form>
</div>
<?php /**PATH /home/sheri-kambooh/Desktop/laravel/blog/resources/views/edit.blade.php ENDPATH**/ ?>