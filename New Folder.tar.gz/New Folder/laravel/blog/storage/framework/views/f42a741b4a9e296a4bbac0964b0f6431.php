<div>
    <h1>Student List</h1>
    <table border="1">
        <tr>
            <td>Name</td>
            <td>Email</td>
            <td>Phone</td>
            <td>Created</td>
            <td>operation</td>
        </tr>

        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($student->name); ?></td>
            <td><?php echo e($student->email); ?></td>
            <td><?php echo e($student->phone); ?></td>
            <td><?php echo e($student->created_at); ?></td>
            <td><a href="<?php echo e('delete/' .$student->id); ?>">delete</a>
            <a href="<?php echo e('edit/' .$student->id); ?>">edit</a></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div><?php /**PATH /home/sheri-kambooh/Desktop/laravel/blog/resources/views/list-student.blade.php ENDPATH**/ ?>